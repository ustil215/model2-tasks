const array = [9, 5, 2, 6, 23, 6, 8, 1, 9, 2];
let negativeElement = false;
for( let i = 0; i <= array.length; i++) {
    if (array[i] < 0) {
      negativeElement = true;
        break;
    } 
}

if (negativeElement) {
    console.log('Есть отрицательный элемент');
} else {
    console.log('Все элементы положительные');            
}

const arrayNegative = [9, 5, 2, 6, -23, 6, 8, 1, 9, 2];
let negativeEl = false;
for( let i = 0; i <= arrayNegative.length; i++) {
    if (arrayNegative[i] < 0) {
      negativeElement = true;
        break;
    } 
}

if (negativeElement) {
    console.log('Есть отрицательный элемент');
} else {
    console.log('Все элементы положительные');            
}
