const array1 = [4, 1, 8, 5, 23];
const array2 = [654, 2, 8, 4, 7];

const newArray = [].concat(array1, array2)

console.log(newArray);