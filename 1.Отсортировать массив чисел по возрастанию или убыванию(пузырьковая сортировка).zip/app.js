const array = [6, 43, -6, 3, 0, 5, 2, 7];

function sortUp (array) {
    for (let n = 0; n < array.length; n++) {
        for (let i = 0; i < array.length - 1 - n; i++) {
            if (array[i] > array[i + 1]) {
                const move = array[i]
                array[i] = array[i + 1]
                array[i + 1] = move
                
            }
        }
    }
    return array;
}

function sortDown (array) {
    for (let n = 0; n < array.length; n++) {
        for (let i = 0; i < array.length - 1 - n; i++) {
            if (array[i] < array[i + 1]) {
                const move = array[i]
                array[i] = array[i + 1]
                array[i + 1] = move               
            }
        }
    }
    return array;
}

console.log(sortUp(array)); 
console.log(sortDown(array)); 











