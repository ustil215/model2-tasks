const numbers = [5, 3, 8, 2, 9, 4, 1, 7];

const deleteAnArrayElement = (arr, index) => {
  arr.splice(index, 1)

  return arr;
};


console.log(deleteAnArrayElement(numbers, 4));

