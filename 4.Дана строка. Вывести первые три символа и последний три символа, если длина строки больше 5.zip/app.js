const string = 'Hello world';
 
function displaysTheValues (str) {
    if (str.length > 5) {
      return str.substr(0, 3) + str.slice(-3)
    };
}
 
console.log(displaysTheValues(string));
