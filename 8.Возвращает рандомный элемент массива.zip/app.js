const array = [4, 8, 2, 9, 4, 6, 5, 1, 7, 4];

function arrayRandElement(arr) {
  const rand = Math.floor(Math.random() * array.length);
  return array[rand];
}

console.log(arrayRandElement(array));
